DEBUG = True

PORT = 9999

ACTION_DIR_NAME = ("action", )

STATIC_DIR_NAME = "static"

TEMPLATE_DIR_NAME = "template"

COOKIE_SECRET = "61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo="


